jQuery(document).ready(function($){

    // user Posts table 
   $.ajax({
        url: posts_data.ajax_url, 
        type: 'POST', 
        data: {
            action: 'get_current_user_posts',
            security: posts_data.nonce,
        },
        beforSend: function(){
            $('#posts_container').html('<p>Loading posts.....</p>'); 
        },
        success: function (response){
            if(response.success){
                var posts = response.data.posts; 
                var output = `<table class="postlist-wrap" id="postlist_wrap">`;
                output +=`<tr><th>Post Title</th><th>Delete Post</th></tr>`;
                posts.forEach(function (post){
                    output += `<tr id="post-${post.ID}"><td><a href="${post.link}">${post.title}</a></td><td><button class="spd-button" value="${post.ID}">Delete</button></td></tr>`
                }); 

                output += `</table>`;
                $('#posts_container').html(output);
            }else{
                $('#posts_container').html(`<p>`+ response.data.message + `</p>`);
            }
        },
       
   });

//    go to post dashboard  

$(document).on('click', '#spd_post_dashboard_button', function(e){
    e.preventDefault(); 

      $.ajax({
        url: posts_data.ajax_url, 
        type: 'POST', 
        data: {
            action: 'get_current_user_posts',
            security: posts_data.nonce,
        },
        beforSend: function(){
            $('#posts_container').html('<p>Loading posts.....</p>'); 
        },
        success: function (response){
            if(response.success){
                var posts = response.data.posts; 
                

                var output = '<h3>Post Lists</h3>'+
                          '<button class="spd-addpsot-button" id="spd_addpost_button">Add new post</button>' +
                            '<div id="posts_container">';
                output += `<table class="postlist-wrap" id="postlist_wrap">`;
                output +=`<tr><th>Post Title</th><th>Delete Post</th></tr>`;
                posts.forEach(function (post){
                    output += `<tr id="post-${post.ID}"><td><a href="${post.link}">${post.title}</a></td><td><button class="spd-button" value="${post.ID}">Delete</button></td></tr>`
                }); 

                output += `</table></div></div>`;
                $('#postlist_area').html(output);
            }else{
                $('#postlist_area').html(`<p>`+ response.data.message + `</p>`);
            }
        },
      
   });
});

// post delete 
   $(document).on('click', '.spd-button', function(e){
    e.preventDefault();

    if(!confirm('Are you sure you want to delete this post?')){
        return;
    }

    var postId = $(this).val();

    $.ajax({
        url: posts_data.ajax_url, 
        type: 'POST', 
        data:{
            action: 'delete_current_user_post',
            security: posts_data.nonce, 
            post_id: postId
        },
        beforeSend: function(){
            $(`#post-${postId}`).fadeOut();
        },

        success: function(response){
            if (response.success) {
                alert(response.data.message);
                $(`#post-${postId}`).remove(); // Remove the post on success
            } else {
                alert(response.data.message);
                $(`#post-${postId}`).fadeIn(); // Show the post again if failed
            }
        },
    });

   });

//    create post input form
   $(document).on('click', '#spd_addpost_button', function(e){
        e.preventDefault();

        var output = '<div class="new-post-create-area"><h4>Add New Post</h4><p></p>';
        output += '<form method="POST" id="new_post_form">'+
                    '<label for="fname">Post Title:</label>' +
                            '<input type="text" id="post_title" name="post_title"><br>'+
                            '<label for="lname">Post Description:</label>'+
                            '<textarea id="post_description" name="post_description" rows="4" cols="50"></textarea><br><br>'+
                            '<input type="submit" class ="spd-addpsot-button" id="spd_add_post" value="Submit">'+
                    '</form>';
        output += '</div>';
        $('#postlist_area').html(output);
   });


//    create new post 
   $(document).on('submit', '#new_post_form', function(e){
        e.preventDefault(); 

        var postTitle =  $("#post_title").val();
        var postDescription =  $("#post_description").val();

        $.ajax({
            url: posts_data.ajax_url, 
            type: 'POST',

            data:{
                action:'create_new_post',
                security: posts_data.nonce,
                postTitle: postTitle,
                postDescription: postDescription,
            },

            beforeSend: function () {
                $('#spd_add_post').prop('disabled', true).text('Submitting...');
            },

            success: function(response){
                if(response.success){
                    var output = '<h5>' + response.data.message + '</h5>';
                    output += '<button class="spd-std-button" id="spd_addpost_button">Add another post</button><button class="spd-std-button" id="spd_post_dashboard_button">Go to post dashboard</button>';
                    $('#postlist_area').html(output);
                }else{
                    alert(response.data.message);
                }
            },


        });




   });

});