<?php
/**
 * Plugin Name:       Self Posts Dashboard
 * Plugin URI:        https://kazimahmud.com/
 * Description:       Users posts dsahboard.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Kazi Mahmud Al Azad
 * Author URI:        https://kazimahmud.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       kmpd
 * Domain Path:       /languages
 */
 

 if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// main class for this plugin 
final class Self_Posts_Dashboard{

    // variable for self instance 
    private static $instance = null;

    private function __construct() {
        // register ajax action 
        add_action('wp_ajax_get_current_user_posts', array( $this,'get_user_posts') );
        
        add_action('wp_ajax_delete_current_user_post', array( $this,'delete_user_post') );

        add_action('wp_ajax_create_new_post', array( $this,'create_a_new_post') );

        // enqueue all styles and scripts 
        add_action('wp_enqueue_scripts', array( $this,'self_post_dashboard_style') );

        // plugin activation hook  

        register_activation_hook( __FILE__, array( $this,'user_posts_dashboard_page') );

        // create shortcode 
        add_shortcode('post-dashboard', array( $this,'post_dashboard_shortcode_callback') );

        // declare constants function
        $this->define_constants();

       
    }

    // Sefl instance functionality 
    public static function get_instance() {
        if( self::$instance) {
            return self::$instance; 
    }
    self::$instance = new self();
    return self::$instance;
    }

    // contants declareation function 
    public function define_constants(){
        define('SELF_POSTS_PATH', plugin_dir_path( __FILE__ ));
        define('SELF_POSTS_URL', plugin_dir_url( __FILE__ ));

    }

    // enqueue related functionality 
    public function self_post_dashboard_style(){
        $css_file_path = SELF_POSTS_PATH.'assets/css/style.css';
        wp_enqueue_style('self-post-style', SELF_POSTS_URL .'assets/css/style.css', array(), filemtime( $css_file_path ) );

        wp_enqueue_script('scripts-js', SELF_POSTS_URL .'assets/js/scripts.js', array('jquery', 'wp-util'), '', true );

        wp_localize_script('scripts-js','posts_data', array(
            'ajax_url'=> admin_url('admin-ajax.php'), 
            'nonce'=> wp_create_nonce('user_posts_nonce'), 
            ) );
    }

    // create user post dashboard page  
    public function user_posts_dashboard_page(){

       
        $page_title = 'Users Posts Dashboard';
        
        
        // query for the pages

        $page_check = new WP_Query(array(
            'post_type'     => 'page', 
            'post_status'   => 'publish',

        )); 

        $counter = 0;

        // check for the page if previously created  

       if($page_check->have_posts()){

        while($page_check->have_posts()): $page_check->the_post();
            if(get_the_title() == $page_title){
                $counter++;
            }
        endwhile;
       }

    //    new page information array  
       $new_page = array(
        'post_title'    => $page_title,
        'post_content'  => '[post-dashboard]',
        'post_status'   => 'publish',
        'post_type'     => 'page',
        );

        // If there is no page as our title, create new page $_COOKIE

       if($counter === 0){
        wp_insert_post( $new_page );
       }
       
    //    restore post data 
       wp_reset_postdata();
        
    }


    public function create_a_new_post(){
        // security check  
        check_ajax_referer('user_posts_nonce','security');

        if(!is_user_logged_in()){
            wp_send_json_error( array('message'=> 'Please Log in first!') );
        }

        $post_title = sanitize_text_field($_POST['postTitle']);
        $post_description = sanitize_text_field($_POST['postDescription']);
        $post_author = get_current_user_id();

        if(empty($post_title) || empty($post_description) ){
            wp_send_json_error( array('message'=> 'Title and content are required.'));
        }

        $new_post = array(
            'post_title'        => $post_title,
            'post_content'      => $post_description,
            'post_status'       => 'publish',
            'post_author'       => $post_author,
            'post_date'         => date('Y-m-d H:i:s'),
            'post_type'         => 'post',
    
        ); 

        $add_new_post = wp_insert_post( $new_post );

        if($add_new_post){
            wp_send_json_success( array('message'=> 'New post has been posted.') );
        }else{
            wp_send_json_error( array('message'=> 'Failed to add post.') );
        }
    }

// get user posts 
    public function get_user_posts(){

        // security check 
        check_ajax_referer('user_posts_nonce', 'security');

        if(!is_user_logged_in()){
            wp_send_json_error( array('message'=> 'You must be logged in to view your posts.') );
        }
      
        // get current user id  
        $user_id = get_current_user_id();

        // query arguments 
        $query_args = array(
            'author'        => $user_id,
            'post_type'     => 'post',
            'post_status'   => 'publish',
            'posts_per_page'=> -1,
        );

        // poat query 
        $user_posts = new WP_Query( $query_args );

        // checing query have posts  
        if($user_posts->have_posts()){
            $all_posts = array();

            // posts loop  
            while($user_posts->have_posts()){
                $user_posts->the_post();
                $all_posts[] = array(
                    'ID'        => get_the_id(),
                    'title'     => get_the_title(),
                    'link'      => get_permalink(),
                );	
            }
            // all post send to ajax 
            wp_send_json_success( array('posts' => $all_posts )); 
        }else{
            // message sen to ajax  
            wp_send_json_error( array('message'=> 'No Post Found!') );
        } 

        wp_reset_postdata();
    }


// delete post function  
    public function delete_user_post(){

        // security check  
        check_ajax_referer('user_posts_nonce', 'security');

        // check the user in not logged in   
        if(!is_user_logged_in()){
            wp_send_json_error( array('message'=> 'You must be logged in to delete a post.') );
        }

        // get the post id from ajax request 
        $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;

        // check the post value 
        if(empty($post_id)){
            wp_send_json_error( array('message'=> 'Invalid Post Id..') );
        }

        $post = get_post($post_id);

        // post author id check 
        if($post->post_author != get_current_user_id()){
            wp_send_json_error( array('message'=> 'You do not have permission to delete this post.') );
        }

        // delete the post 
        $deleted = wp_delete_post($post_id, true);

        if ($deleted) {
            // delete success message send to ajax 
            wp_send_json_success(['message' => 'Post deleted successfully.', 'post_id' => $post_id]);
        } else {
            // delete failed message  
            wp_send_json_error(['message' => 'Failed to delete the post.']);
        }


    }

    public function post_dashboard_shortcode_callback(){
        ob_start();
        ?>
            <div class="postlist-area" id="postlist_area">
                <h3>Post Lists</h3>
                <button class="spd-addpsot-button" id="spd_addpost_button">Add new post</button>
                    <div id="posts_container">
                        <table class="postlist-wrap" id="postlist_wrap">
                            <tr>
                                <th>Post Title</th>
                                <th>Delete Post</th>
                            </tr>
                    
                            <tr>
                                <td><a href=""></a></td>
                                <td><button class="spd-button">Delete</button></td>
                            </tr>
                    
                        </table>
                    </div>
            </div>

        <?php
        return ob_get_clean();
    }
   

}

Self_Posts_Dashboard::get_instance();

?>